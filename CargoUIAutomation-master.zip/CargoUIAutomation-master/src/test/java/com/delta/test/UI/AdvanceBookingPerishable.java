package com.delta.test.UI;

import com.delta.util.BaseTest;

public class AdvanceBookingPerishable extends BaseTest {


}
