package com.delta.util;

import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import java.awt.*;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class CommonMethod {

    WebDriver driver;


    public void waitUntilCssSelectorElementIsClickable(WebDriver driver, String xlWebElement) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(xlWebElement)));
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        WebElement element = driver.findElement(By.cssSelector(xlWebElement));
        executor.executeScript("arguments[0].click();", element);


    }

    public void waitUntilXpathElementIsClickable(WebDriver driver, String xlWebElement) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xlWebElement)));
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        WebElement element = driver.findElement(By.xpath(xlWebElement));
        executor.executeScript("arguments[0].click();", element);

    }


    public void sendkeysUsingXpath(WebDriver driver, String xlWebElement, String sendKeyValue) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xlWebElement)));
        driver.findElement(By.xpath(xlWebElement)).sendKeys(sendKeyValue);
        driver.findElement(By.xpath(xlWebElement)).sendKeys(Keys.ENTER);

//
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xlWebElement)));
//        JavascriptExecutor executor = (JavascriptExecutor) driver;
//        WebElement element = driver.findElement(By.cssSelector(xlWebElement));
//        executor.executeScript("arguments[0].value='" + sendKeyValue + "';", element);
//        executor.executeScript("arguments[0].click();", element);
    }

    public void sendkeysUsingCssSelector(WebDriver driver, String xlWebElement, String sendKeyValue)  {

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(xlWebElement)));
        driver.findElement(By.cssSelector(xlWebElement)).sendKeys(sendKeyValue);
        driver.findElement(By.cssSelector(xlWebElement)).sendKeys(Keys.ENTER);



//        JavascriptExecutor executor = (JavascriptExecutor) driver;
//        WebElement element = driver.findElement(By.cssSelector(xlWebElement));
//        executor.executeScript("arguments[0].value='" + sendKeyValue + "';", element);
//       // executor.executeScript("arguments[0].click();", element);
//        element.click();
//
//
//     /*  // WebElement element = driver.findElement(By.xpath("xpath"));
//        Actions action = new Actions(driver);
//        action.moveToElement(element).build().perform();
//        action.moveToElement(element).click();*/
//        try {
//            Thread.sleep(10000);
//        } catch (InterruptedException e) {
//            throw new RuntimeException(e);
//        }
    }


    public void ClickOnRadiobutton(WebDriver driver, String xlWebElement) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(xlWebElement)));

    }


    public void waitForPageLoad(WebDriver driver) {
        try {
            driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));

        } catch (Exception e) {
            e.printStackTrace();
            //Report.getLogger().log(Status.FAIL, "Exception occured while waiting for page load", var2);
          //  Reporter.log(Status.FAIL, "user logged In Successfully");
        }

    }

    public void selectDropdownUsingCssSelector(WebDriver driver,String element ,String  dropDownValue){
        List<WebElement> webShipmentContains = driver.findElements(By.cssSelector(element));
        for (int i = 0; webShipmentContains.size() > i; i++) {
            String webShipmentValue = webShipmentContains.get(i).getText().toString();
            if (webShipmentValue.equalsIgnoreCase(dropDownValue)) {
                webShipmentContains.get(i).click();
            }
        }
    }

    public void selectDropdownUsingXpath(WebDriver driver,String element ,String  dropDownValue){
        List<WebElement> webShipmentContains = driver.findElements(By.xpath(element));
        for (int i = 0; webShipmentContains.size() > i; i++) {
            String webShipmentValue = webShipmentContains.get(i).getText().toString();
            if (webShipmentValue.equalsIgnoreCase(dropDownValue)) {
                webShipmentContains.get(i).click();
            }
        }
    }
}
